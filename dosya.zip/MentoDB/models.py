from pydantic import BaseModel

class DefaultModel(BaseModel):
    id: int

